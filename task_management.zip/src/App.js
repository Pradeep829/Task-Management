import './App.css';
import TaskManager from './components/TaskManger/TaskManager';

function App() {
  return (
    <div className="App">
     <TaskManager/>
    </div>
  );
}

export default App;
