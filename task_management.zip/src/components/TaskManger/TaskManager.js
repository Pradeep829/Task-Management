import React, { useState, useEffect } from 'react';
import Styles from "./taskmanager.module.css";
import filter from "../../assets/png/filter.png";
import Modal from 'react-modal';

Modal.setAppElement('#root');

const TaskManager = () => {
  const [tasks, setTasks] = useState([]);
  const [filteredTasks, setFilteredTasks] = useState([]);
  const [activeFilter, setActiveFilter] = useState('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [currentTask, setCurrentTask] = useState(null);
  const [mode, setMode] = useState('create');
  const [taskToDelete, setTaskToDelete] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showFilterOptions, setShowFilterOptions] = useState(false);

  const [formData, setFormData] = useState({
    title: '',
    comment: '',
    dueDate: new Date(),
    status: 'Pending',
    isCompleted: false
  });

  useEffect(() => {
    const loadTasks = () => {
      setIsLoading(true);
      try {
        const savedTasks = localStorage.getItem('tasks');
        const parsedTasks = savedTasks ? JSON.parse(savedTasks) : [];

        if (parsedTasks.length > 0) {
          setTasks(parsedTasks);
          setFilteredTasks(parsedTasks);
        } else {
          const initialTask = [{
            id: Date.now().toString(),
            title: 'Sample Task',
            comment: 'This is your first task!',
            dueDate: new Date().toISOString(),
            status: 'Pending',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          }];
          localStorage.setItem('tasks', JSON.stringify(initialTask));
          setTasks(initialTask);
          setFilteredTasks(initialTask);
        }
      } catch (error) {
        alert('Failed to load tasks');
        console.error(error);
      } finally {
        setIsLoading(false);
      }
    };

    loadTasks();
  }, []);

  useEffect(() => {
    let filtered = [];
    switch (activeFilter) {
      case 'Completed':
        filtered = tasks.filter(task => task.status === 'Completed');
        break;
      case 'Pending':
        filtered = tasks.filter(task => task.status === 'Pending');
        break;
      default:
        filtered = [...tasks];
    }
    setFilteredTasks(filtered);
  }, [activeFilter, tasks]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
      ...(name === 'isCompleted' && { status: checked ? 'Completed' : 'Pending' })
    }));
  };

  const handleDateChange = (date) => {
    setFormData(prev => ({
      ...prev,
      dueDate: date
    }));
  };

  const openModal = (task = null, modalMode = 'create') => {
    if (task) {
      setCurrentTask(task);
      setFormData({
        title: task.title,
        comment: task.comment,
        dueDate: new Date(task.dueDate),
        status: task.status,
        isCompleted: task.status === 'Completed'
      });
    } else {
      setFormData({
        title: '',
        comment: '',
        dueDate: new Date(),
        status: 'Pending',
        isCompleted: false
      });
    }
    setMode(modalMode);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentTask(null);
  };

  const openDeleteModal = (task) => {
    setTaskToDelete(task);
    setIsDeleteModalOpen(true);
  };

  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
    setTaskToDelete(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const newTask = {
        id: currentTask?.id || Date.now().toString(),
        title: formData.title,
        comment: formData.comment,
        dueDate: formData.dueDate.toISOString(),
        status: formData.isCompleted ? 'Completed' : 'Pending',
        createdAt: currentTask?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      let updatedTasks;
      if (mode === 'edit' && currentTask) {
        updatedTasks = tasks.map(task =>
          task.id === currentTask.id ? newTask : task
        );
        alert('Task updated successfully!');
      } else {
        updatedTasks = [...tasks, newTask];
        alert('Task created successfully!');
      }

      localStorage.setItem('tasks', JSON.stringify(updatedTasks));
      setTasks(updatedTasks);
      closeModal();
      setTimeout(() => window.location.reload(), 1500);
    } catch (error) {
      alert('Failed to save task');
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

const handleDelete = () => {
  setIsLoading(true);
  try {
    const updatedTasks = tasks.filter(task => task.id !== taskToDelete.id);
    localStorage.setItem('tasks', JSON.stringify(updatedTasks));
    setTasks(updatedTasks); 
    alert('Task deleted successfully!');
    closeDeleteModal();
  } catch (error) {
    alert('Failed to delete task');
    console.error(error);
  } finally {
    setIsLoading(false);
  }
};


  const toggleTaskStatus = (taskId) => {
    setIsLoading(true);
    try {
      const updatedTasks = tasks.map(task => {
        if (task.id === taskId) {
          return {
            ...task,
            status: task.status === 'Pending' ? 'Completed' : 'Pending',
            updatedAt: new Date().toISOString()
          };
        }
        return task;
      });

      localStorage.setItem('tasks', JSON.stringify(updatedTasks));
      setTasks(updatedTasks);
      alert('Task status updated!');
      setTimeout(() => window.location.reload(), 1500);
    } catch (error) {
      alert('Failed to update task status');
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const applyFilter = (filterType) => {
    setActiveFilter(filterType);
    setShowFilterOptions(false);
  };

  const clearFilter = () => {
    setActiveFilter('All');
    setShowFilterOptions(false);
  };

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <div className={Styles.taskmanager}>
      {isLoading && (
        <div className={Styles.loader}>
          <div className={Styles.spinner}></div>
        </div>
      )}

      <div className={Styles.header}>
        <h1>Task Manager</h1>
        <button onClick={() => openModal(null, 'create')}>Add Tasks</button>
        <div className={Styles.filtercontainer}>
          <img 
            src={filter} 
            alt="filter" 
            className={Styles.filtericon}
            onClick={() => setShowFilterOptions(!showFilterOptions)}
          />
          {showFilterOptions && (
            <div className={Styles.filteroptions}>
              <div className={Styles.options} onClick={() => applyFilter('All')}>All</div>
              <div className={Styles.options}  onClick={() => applyFilter('Pending')}>Pending</div>
              <div className={Styles.options} onClick={() => applyFilter('Completed')}>Completed</div>
              <div className={Styles.clearoption} onClick={clearFilter}>Clear</div>
            </div>
          )}
        </div>
      </div>

      <div className={Styles.taskscontainer}>
        <div className={Styles.tasksection}>
          <h2>{activeFilter} Tasks</h2>
          <div className={Styles.tasklist_main}>
          <div className={filteredTasks.length === 0 ? `${Styles.tasklist} ${Styles.noTask}` : Styles.tasklist}>
            {filteredTasks.length === 0 ? (
              <p className={Styles.notask_text}>No tasks found</p>
            ) : (
              filteredTasks.map(task => (
                <div key={task.id} className={`${Styles.taskcard} ${task.status === 'Completed' ? Styles.completed : ''}`}>
                  <div className={Styles.taskheader}>
                    <h3>{task.title}</h3>
                    <span className={`${Styles.status} ${task.status === 'Completed' ? Styles.completedstatus : Styles.pendingstatus}`}>
                      {task.status}
                    </span>
                  </div>

                  <div className={Styles.taskfooter}>
                    <span>Due: {formatDate(task.dueDate)}</span>
                    <div className={Styles.taskactions}>
                      <button onClick={() => openModal(task, 'view')}>View</button>
                      <button onClick={() => openModal(task, 'edit')}>Edit</button>
                      <button onClick={() => openDeleteModal(task)}>Delete</button>
                      <button onClick={() => toggleTaskStatus(task.id)}>
                        {task.status === 'Pending' ? 'Mark Complete' : 'Mark Pending'}
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
          </div>
        </div>
      </div>

      {/* Add/Edit/View Task Modal */}
      <Modal
        isOpen={isModalOpen}
        onRequestClose={closeModal}
        className={Styles.modal}
        overlayClassName={Styles.overlay}
      >
        <h2>{mode === 'create' ? 'Add New Task' : mode === 'edit' ? 'Edit Task' : 'Task Details'}</h2>
        <form onSubmit={handleSubmit}>
          <div className={Styles.formgroup}>
            <label>Title:</label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              required
              disabled={mode === 'view'}
            />
          </div>
          <div className={Styles.formgroup}>
            <label>Comment:</label>
            <textarea
              name="comment"
              value={formData.comment}
              onChange={handleInputChange}
              disabled={mode === 'view'}
            />
          </div>
          <div className={Styles.formgroup}>
            <label>Due Date:</label>
            <input
              type="date"
              value={formData.dueDate.toISOString().split('T')[0]}
              onChange={(e) => handleDateChange(new Date(e.target.value))}
              disabled={mode === 'view'}
              required
              className={Styles.date_input}
            />
          </div>
          <div className={Styles.formgroup}>
            <label className={Styles.checkbox_label}>
              <input
                type="checkbox"
                name="isCompleted"
                checked={formData.isCompleted}
                onChange={handleInputChange}
                disabled={mode === 'view'}
              />
              Mark as completed
            </label>
          </div>
          <div className={Styles.modalbuttons}>
          <button type="button" onClick={closeModal} className={Styles.cancelbutton}>Cancel</button>
            <button type="submit" className={Styles.submitbutton}>Save</button>
    
          </div>
        </form>
      </Modal>

      {/* Delete Task Modal */}
      <Modal
        isOpen={isDeleteModalOpen}
        onRequestClose={closeDeleteModal}
        className={Styles.modal}
        overlayClassName={Styles.overlay}
      >
        <h2>Are you sure you want to delete this task?</h2>
        <div className={Styles.modalbuttons}>
        <button onClick={closeDeleteModal} className={Styles.cancelbutton}>Cancel</button>
          <button onClick={handleDelete} className={Styles.deletebutton}>Delete</button>

        </div>
      </Modal>
    </div>
  );
};

export default TaskManager;
